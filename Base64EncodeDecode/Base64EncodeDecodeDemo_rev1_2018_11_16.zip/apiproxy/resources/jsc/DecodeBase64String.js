var base64EncodedKey = context.getVariable("request.queryparam.key");
var key = Base64.decode(base64EncodedKey);
print(key);